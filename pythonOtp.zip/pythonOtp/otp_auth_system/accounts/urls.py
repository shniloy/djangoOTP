from django.urls import path
from .views import signup_view, verify_otp_view, home_view

urlpatterns = [
    path('', home_view, name='home'),  # The empty path should map to home_view
    path('signup/', signup_view, name='signup'),
    path('verify-otp/', verify_otp_view, name='verify_otp'),
]
