from django import forms
from django.contrib.auth.models import User

class SignupForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['username', 'email']

class OTPForm(forms.Form):
    otp_code = forms.CharField(max_length=6)
