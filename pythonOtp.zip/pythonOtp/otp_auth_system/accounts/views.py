from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from .forms import SignupForm, OTPForm
from .models import OTP
from .utils import generate_otp, send_otp_via_email
from django.utils import timezone
from django.contrib.auth import login




def home_view(request):
    return render(request, 'home.html')


def signup_view(request):
    if request.method == 'POST':
        form = SignupForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_unusable_password()  # We are not setting a password here
            user.is_active = False  # The user will be inactive until OTP verification
            user.save()

            otp_code = generate_otp()
            OTP.objects.create(user=user, otp_code=otp_code)
            send_otp_via_email(user.email, otp_code)

            request.session['user_id'] = user.id
            return redirect('verify_otp')
    else:
        form = SignupForm()
    return render(request, 'signup.html', {'form': form})

def verify_otp_view(request):
    user_id = request.session.get('user_id')
    if not user_id:
        return redirect('signup')

    user = User.objects.get(id=user_id)
    otp_instance = OTP.objects.get(user=user)

    if request.method == 'POST':
        form = OTPForm(request.POST)
        if form.is_valid():
            otp_code = form.cleaned_data['otp_code']
            if otp_instance.otp_code == otp_code and otp_instance.is_valid():
                user.is_active = True
                user.save()
                login(request, user)
                return redirect('home')
            else:
                return render(request, 'verify_otp.html', {'form': form, 'error': 'Invalid or expired OTP.'})
    else:
        form = OTPForm()

    return render(request, 'verify_otp.html', {'form': form})
